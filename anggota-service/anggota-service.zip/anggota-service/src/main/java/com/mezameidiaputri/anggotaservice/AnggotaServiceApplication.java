package com.mezameidiaputri.anggotaservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnggotaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnggotaServiceApplication.class, args);
	}

}
